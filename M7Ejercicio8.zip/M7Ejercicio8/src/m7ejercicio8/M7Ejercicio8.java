package m7ejercicio8;

import java.util.Scanner;

public class M7Ejercicio8 {
	
	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int celsius;
		
		
		System.out.println("Introduzca la temperatura en Grados Centígrados : ");
		celsius = sc.nextInt();
		farConverter(celsius);
	}

public static void farConverter(int t) {
	final int K = 32;
	float far = (t*9/5) + K;
	System.out.println("La temperatura "+t+" grados celsius equivale a "+far+" grados Fahrenheit");
}
}
