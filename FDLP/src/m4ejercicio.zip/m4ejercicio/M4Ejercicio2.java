package m4ejercicio;

import java.util.Scanner;

public class M4Ejercicio2 {


		public static void main(String[] args) {
		
			 Scanner sc = new Scanner(System.in);
			 byte edad;
			 
			 System.out.println("introduce tu edad : ");
			 edad = sc.nextByte();
			 
			 if (edad >= 18) {
				 System.out.println("FP o Universidad");
				 }
			 else if(edad <= 15) {
				 if (edad <= 6) {
					 System.out.println("Preescolar"); }
				 else if (edad >= 12){
					 System.out.println("ESO");
			 }
				 else {
					 System.out.println("Primaria");
				 }


	}
			 else {
				 System.out.println("Bachillerato");
	
	}
		}
}
