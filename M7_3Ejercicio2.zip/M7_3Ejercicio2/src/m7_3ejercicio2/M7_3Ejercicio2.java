package m7_3ejercicio2;

import java.util.Scanner;

public class M7_3Ejercicio2 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String palabra;
		
		System.out.println("Introduce una palabra o frase");
		palabra = sc.nextLine();
		reversePalabra(palabra);
	
	}
	public static void reversePalabra(String palabra) {
		int longitud = palabra.length();
		int posicion = longitud-1;
		char caracter = ' ';
		String reverse ="";
		for (int i = posicion; i>=0;i--) {
			caracter = palabra.charAt(i);
			reverse += caracter;
		}
		System.out.println(reverse);
	}

}
