package pooclase2;

public class POOClase2 {

	public static void main(String[] args) {
		
		Ordenador cpu1 = new Ordenador("HP", "4700P");
		
		
		Ordenador cpu2 = new Ordenador("Packard Bell", "345HT","Pentium", 16, 1000 );
		

		cpu1.programa("Eclipse");
		
		System.out.println(cpu1.getMarca());
		
		System.out.println(cpu2.getProcesador());
		
		System.out.println(cpu2.toString());
		System.out.println(cpu1.toString());

	}

}
