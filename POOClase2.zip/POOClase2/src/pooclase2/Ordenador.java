package pooclase2;

public class Ordenador {
		//atributos de la clase Ordenador
		private String marca;
		private String modelo;
		private String procesador;
		private int ram;
		private int discoduroMb;
		
		//metodo de la clase que realiza la accion de imprimir el nombre del programa		
		public void programa (String programa) {
			System.out.println("En estos momentos se esta ejecutando "+programa);
		}
		//getters y setters
		public String getProcesador() {
			return procesador;
		}
		
		public void setProcesador(String procesador) {
			this.procesador = procesador;
		}
		
		public int getRam() {
			return ram;
		}

		public void setRam(int ram) {
			this.ram = ram;
		}

		public int getDiscoduroMb() {
			return discoduroMb;
		}

		public void setDiscoduro(int discoduroMb) {
			this.discoduroMb = discoduroMb;
		}

		public String getMarca() {
			return marca;
		}

		public String getModelo() {
			return modelo;
		}
		public Ordenador(String marca, String modelo, String procesador, int ram, int discoduroMb) {
			super();
			this.marca = marca;
			this.modelo = modelo;
			this.procesador = procesador;
			this.ram = ram;
			this.discoduroMb = discoduroMb;
		}
		public Ordenador(String marca, String modelo) {
			super();
			this.marca = marca;
			this.modelo = modelo;
		}
		@Override
		public String toString() {
			return "Ordenador [marca=" + marca + ", modelo=" + modelo + ", procesador=" + procesador + ", ram=" + ram
					+ ", discoduroMb=" + discoduroMb + "]";
		}
	



	}

