package m7ejercicio7;

import java.util.Scanner;

public class M7Ejercicio7 {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		int numero;
		String caracter;
		
		
		System.out.println("Introduczca un numero (lado del cuadrado)");
		numero = sc.nextInt();
		sc.nextLine();
		System.out.println("Introduczca el caracter");
		caracter = sc.nextLine();
		
		printSquare(numero, caracter);
	
	}
	
	public static void printSquare(int x, String e){
		int i=0,j;
		do {
	for (j=1; j <=x; j++) {
		System.out.print(e);
		}
	i++;
	System.out.println("\n");
	} while (i<=x);
	}
}
