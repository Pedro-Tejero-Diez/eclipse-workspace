package m5ejercicio5;

public class M7Ejercicio5 {

	public static void main(String[] args) {
		
		int a=100, i;
		
		for (i=0; i<51;i++) {
			System.out.println(a);
			a = a-2;
		}

	}

}
