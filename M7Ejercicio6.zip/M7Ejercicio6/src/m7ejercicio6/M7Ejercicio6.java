package m7ejercicio6;

import java.util.Scanner;

public class M7Ejercicio6 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		int numero, i;
	

		System.out.println("Introduzca el numero del que quiere saber la tabla de multiplicar");
		numero = sc.nextInt();

		for (i = 0; i <= 10; i++) {
			System.out.println(numero+" x "+i+" es "+numero*i);
		}
	}
}
