package m7ejercicio4;

import java.util.Scanner;

public class M7Ejercicio4 {


	public static void main(String[] args) {
			
			Scanner sc = new Scanner(System.in);
			int numero1, numero2;
			
				
				System.out.println("Introduzca un numero :");
				numero1 = sc.nextInt();

				System.out.println("Introduzca un numero :");
				numero2=sc.nextInt();
				
				if (numero1*numero2 < 0) {
					
				System.out.println("Hay un numero negativo");
		 }

	}

}
